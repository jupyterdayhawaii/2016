# JupyterDayHawaii2016
Repository for JupyterDay Hawaii 2016 Tutorials and Tech Talks (and stuff)
